<?php
/**
 * Plugin Name: Builder API
 * Description: Generated REST API for Next.js Builder integration.
 * Version: 1.9.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'BUILDER_API_VERSION', '1' );
define( 'BUILDER_API_TEMPLATE_SOURCE', 'taxonomy' );
define( 'BUILDER_API_TEMPLATE_KEY', 'page_template_type' );

function builder_api_resolve_templates( int $post_id ): array {
	switch ( BUILDER_API_TEMPLATE_SOURCE ) {
		case 'taxonomy':
			return builder_api_templates_from_taxonomy( $post_id );
		case 'acf':
			return builder_api_templates_from_acf( $post_id );
		case 'meta':
			return builder_api_templates_from_meta( $post_id );
		case 'elementor':
			return builder_api_templates_from_elementor( $post_id );
		default:
			return [];
	}
}

function builder_api_templates_from_taxonomy( int $post_id ): array {
	if ( BUILDER_API_TEMPLATE_KEY === '' ) return [];
	if ( ! taxonomy_exists( BUILDER_API_TEMPLATE_KEY ) ) return [];

	$terms = get_the_terms( $post_id, BUILDER_API_TEMPLATE_KEY );
	if ( ! $terms || is_wp_error( $terms ) ) return [];

	$unique = [];
	foreach ( $terms as $term ) {
		$unique[ $term->slug ] = [ 'slug' => $term->slug, 'id' => (int) $term->term_id, 'name' => $term->name ];
	}
	ksort( $unique );
	return array_values( $unique );
}

function builder_api_templates_from_acf( int $post_id ): array {
	if ( BUILDER_API_TEMPLATE_KEY === '' || ! function_exists( 'get_field' ) ) return [];

	$value = get_field( BUILDER_API_TEMPLATE_KEY, $post_id );
	if ( ! $value ) return [];

	$unique = [];
	foreach ( ( is_array( $value ) ? $value : [ $value ] ) as $item ) {
		$entry = builder_api_template_entry( $item );
		if ( $entry ) $unique[ $entry['slug'] ] = $entry;
	}
	ksort( $unique );
	return array_values( $unique );
}

function builder_api_template_entry( $item ): ?array {
	if ( $item instanceof WP_Term ) {
		return [ 'slug' => $item->slug, 'id' => (int) $item->term_id, 'name' => $item->name ];
	}
	if ( $item instanceof WP_Post ) {
		return [ 'slug' => $item->post_name, 'id' => (int) $item->ID, 'name' => get_the_title( $item ) ];
	}
	if ( is_numeric( $item ) ) {
		$term = get_term( (int) $item );
		if ( $term && ! is_wp_error( $term ) ) {
			return [ 'slug' => $term->slug, 'id' => (int) $term->term_id, 'name' => $term->name ];
		}
		return null;
	}
	if ( is_string( $item ) && $item !== '' ) {
		return [ 'slug' => sanitize_title( $item ), 'id' => 0, 'name' => $item ];
	}
	return null;
}

function builder_api_templates_from_meta( int $post_id ): array {
	$file = get_page_template_slug( $post_id );
	if ( ! $file || $file === 'default' ) return [];

	$slug      = sanitize_title( preg_replace( '/\.php$/', '', basename( $file ) ) );
	$templates = wp_get_theme()->get_page_templates( get_post( $post_id ) );
	return [ [ 'slug' => $slug, 'id' => 0, 'name' => $templates[ $file ] ?? $slug ] ];
}

function builder_api_templates_from_elementor( int $post_id ): array {
	$html = builder_api_rendered_html( $post_id );
	if ( ! $html ) return [];

	if ( ! preg_match_all( '/elementor-page-(\d+)/', $html, $matches ) ) return [];

	$unique = [];
	foreach ( array_unique( array_map( 'intval', $matches[1] ) ) as $id ) {
		if ( $id === $post_id ) continue;
		$slug = 'elementor-' . $id;
		$tpl  = get_post( $id );
		$unique[ $slug ] = [ 'slug' => $slug, 'id' => $id, 'name' => $tpl ? get_the_title( $tpl ) : $slug ];
	}
	ksort( $unique );
	return array_values( $unique );
}

/**
 * Elementor element ids that actually render for this page.
 *
 * Answers "does this element exist on this page?" — a different question from ACF's "does this
 * field have data?". Some elements are structurally optional with no ACF signal at all, so their
 * presence is only knowable from rendered output.
 *
 * Rendered via the page's own permalink rather than \Elementor\Plugin's document API: a page is
 * assembled from several documents (theme-builder templates, global sections) whose visibility
 * conditions are evaluated at render time, and the page's own document may not render at all.
 * Requesting the permalink is the only source that reflects what a visitor actually receives.

 */
function builder_api_rendered_html( int $post_id ): string {
	static $memo = [];
	if ( isset( $memo[ $post_id ] ) ) return $memo[ $post_id ];

	$url = get_permalink( $post_id );
	if ( ! $url ) return '';

	$response = wp_remote_get( add_query_arg( 'builder_presence', '1', $url ), [
		'timeout'   => 15,
		'sslverify' => false,
		'headers'   => [ 'X-Builder-Presence' => '1' ],
	] );

	if ( is_wp_error( $response ) ) return '';
	if ( (int) wp_remote_retrieve_response_code( $response ) !== 200 ) return '';

	return $memo[ $post_id ] = (string) wp_remote_retrieve_body( $response );
}

function builder_api_present_elements( int $post_id ): array {
	$cache_key = 'builder_present_' . $post_id . '_' . get_post_modified_time( 'U', true, $post_id );
	$cached    = get_transient( $cache_key );
	if ( is_array( $cached ) ) return $cached;

	$html = builder_api_rendered_html( $post_id );
	if ( ! $html ) return [];

	$ids = [];
	if ( preg_match_all( '/elementor-element elementor-element-([a-z0-9]+)/', $html, $matches ) ) {
		$ids = array_values( array_unique( $matches[1] ) );
		sort( $ids );
	}
	set_transient( $cache_key, $ids, DAY_IN_SECONDS );
	return $ids;
}

/**
 * Resolve the requested page, most specific identifier first.
 *
 * A slug is NOT unique across a page tree — /location-served/drug-rehab and
 * /location-served/usa/drug-rehab share one. Resolving by slug alone silently returns whichever
 * WordPress orders first, so fields/seo/present can all describe a different page than the caller
 * asked for. Ids are immutable, paths are unique, slugs are neither; slug stays last so older
 * exports keep working unchanged.
 */
function builder_api_resolve_post( WP_REST_Request $request ): ?WP_Post {
	$id = (int) $request->get_param( 'id' );
	if ( $id > 0 ) {
		$post = get_post( $id );
		if ( $post && $post->post_status === 'publish' && is_post_type_viewable( $post->post_type ) ) {
			return $post;
		}
	}

	$path = $request->get_param( 'path' );
	if ( $path ) {
		$post = get_page_by_path( trim( $path, '/' ) );
		if ( $post && $post->post_status === 'publish' ) {
			return $post;
		}
		$found = url_to_postid( home_url( '/' . trim( $path, '/' ) . '/' ) );
		if ( $found ) {
			$post = get_post( $found );
			if ( $post && $post->post_status === 'publish' && is_post_type_viewable( $post->post_type ) ) {
				return $post;
			}
		}
	}

	$slug = $request->get_param( 'slug' );
	if ( ! $slug ) return null;

	$query = new WP_Query( [
		'name'           => $slug,
		'post_type'      => 'page',
		'post_status'    => 'publish',
		'posts_per_page' => 1,
	] );
	if ( $query->have_posts() ) return $query->posts[0];

	$query = new WP_Query( [
		'name'           => $slug,
		'post_type'      => array_keys( get_post_types( [ 'public' => true ] ) ),
		'post_status'    => 'publish',
		'posts_per_page' => 1,
	] );

	return $query->have_posts() ? $query->posts[0] : null;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'builder/v1', '/page-data', [
		'methods'             => 'GET',
		'callback'            => 'builder_api_page_data',
		'permission_callback' => '__return_true',
		'args'                => [
			'id'      => [ 'sanitize_callback' => 'absint' ],
			'path'    => [ 'sanitize_callback' => 'sanitize_text_field' ],
			'slug'    => [ 'sanitize_callback' => 'sanitize_text_field' ],
			'present' => [ 'sanitize_callback' => 'rest_sanitize_boolean' ],
		],
	] );
	register_rest_route( 'builder/v1', '/pages', [
		'methods'             => 'GET',
		'callback'            => 'builder_api_pages',
		'permission_callback' => '__return_true',
	] );
	register_rest_route( 'builder/v1', '/field-groups', [
		'methods'             => 'GET',
		'callback'            => 'builder_api_field_groups',
		'permission_callback' => '__return_true',
	] );
} );

function builder_api_page_data( WP_REST_Request $request ): WP_REST_Response {
	nocache_headers();

	$post = builder_api_resolve_post( $request );

	if ( ! $post ) {
		return new WP_REST_Response( [ 'error' => 'not_found' ], 404 );
	}

	$post_id = $post->ID;
	$fields  = [];

	if ( function_exists( 'get_fields' ) ) {
		$acf = get_fields( $post_id );
		if ( is_array( $acf ) ) {
			foreach ( $acf as $key => $value ) {
				if ( is_array( $value ) && isset( $value['url'] ) ) {
					$fields[ $key ] = esc_url_raw( $value['url'] );
					if ( ! empty( $value['alt'] ) ) {
						$fields[ $key . '___alt' ] = (string) $value['alt'];
					}
				} else {
					$normalized = builder_api_normalize_value( $value );
					if ( $normalized !== null ) {
						$fields[ $key ] = $normalized;
					}
				}
			}
		}
	}

	foreach ( get_object_taxonomies( $post->post_type ) as $tax ) {
		$terms = get_the_terms( $post_id, $tax );
		if ( $terms && ! is_wp_error( $terms ) ) {
			$fields[ $tax ]              = implode( ', ', wp_list_pluck( $terms, 'name' ) );
			$fields[ $tax . '___slugs' ] = implode( ',', wp_list_pluck( $terms, 'slug' ) );
		}
	}

	$template_terms = builder_api_resolve_templates( $post_id );
	$template_slugs = wp_list_pluck( $template_terms, 'slug' );
	$template       = $template_slugs ? $template_slugs[0] : '';

	$parent_slug = '';
	if ( $post->post_parent ) {
		$parent_slug = get_post_field( 'post_name', $post->post_parent );
	}

	return new WP_REST_Response( [
		'apiVersion'      => BUILDER_API_VERSION,
		'id'              => (int) $post_id,
		'template'        => $template,
		'templates'       => [
			'slugs' => $template_slugs,
			'ids'   => array_map( 'intval', wp_list_pluck( $template_terms, 'id' ) ),
			'names' => wp_list_pluck( $template_terms, 'name' ),
		],
		'templateVersion' => null,
		'slug'            => $post->post_name,
		'fields'          => $fields,
		'present'         => $request->get_param( 'present' ) ? builder_api_present_elements( $post_id ) : [],
		'seo'             => builder_api_get_seo( $post_id, $post ),
		'meta'            => [
			'slug'      => $post->post_name,
			'parent'    => $parent_slug,
			'updatedAt' => get_post_modified_time( 'c', true, $post_id ),
			'createdAt' => get_post_time( 'c', false, $post_id ),
		],
	], 200 );
}

function builder_api_pages( WP_REST_Request $request ): WP_REST_Response {
	nocache_headers();

	$post_type = $request->get_param( 'post_type' ) ?: 'page';
	if ( ! post_type_exists( $post_type ) || ! is_post_type_viewable( $post_type ) ) {
		return new WP_REST_Response( [ 'error' => 'invalid_post_type' ], 400 );
	}

	$args = [
		'post_type'      => $post_type,
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'fields'         => 'ids',
	];

	$path = $request->get_param( 'path' );
	if ( $path ) {
		$parent_page = get_page_by_path( trim( $path, '/' ) );
		if ( $parent_page ) {
			$args['post_parent'] = $parent_page->ID;
		}
	} elseif ( $parent = $request->get_param( 'parent' ) ) {
		$args['post_parent'] = (int) $parent;
	}

	$template = $request->get_param( 'template' );
	$query    = new WP_Query( $args );
	$results  = [];

	foreach ( $query->posts as $post_id ) {
		if ( $template ) {
			$terms = builder_api_resolve_templates( $post_id );
			if ( ! $terms ) continue;
			if ( ! in_array( $template, wp_list_pluck( $terms, 'slug' ), true ) ) continue;
		}
		$parent_id = (int) get_post_field( 'post_parent', $post_id );
		$results[] = [
			'id'     => (int) $post_id,
			'slug'   => get_post_field( 'post_name', $post_id ),
			'path'   => $post_type === 'page'
				? '/' . get_page_uri( $post_id )
				: rtrim( (string) wp_parse_url( get_permalink( $post_id ), PHP_URL_PATH ), '/' ),
			'parent' => $parent_id ? get_post_field( 'post_name', $parent_id ) : '',
		];
	}

	return new WP_REST_Response( $results, 200 );
}

function builder_api_normalize_value( $value ): ?string {
	if ( is_string( $value ) ) return $value;
	if ( is_numeric( $value ) ) return (string) $value;
	if ( is_bool( $value ) ) return $value ? 'true' : 'false';
	if ( is_array( $value ) && isset( $value['url'] ) ) return esc_url_raw( $value['url'] );
	return null;
}

function builder_api_get_seo( int $post_id, WP_Post $post ): array {
	if ( defined( 'RANK_MATH_VERSION' ) ) {
		$robots    = get_post_meta( $post_id, 'rank_math_robots', true );
		$raw_title = get_post_meta( $post_id, 'rank_math_title', true ) ?: get_the_title( $post_id );
		$title     = class_exists( 'RankMath\Helper' )
			? \RankMath\Helper::replace_vars( $raw_title, get_post( $post_id ) )
			: str_replace( '%sitename%', get_bloginfo( 'name' ), $raw_title );
		return [
			'title'       => $title,
			'description' => (string) get_post_meta( $post_id, 'rank_math_description', true ),
			'canonical'   => (string) get_post_meta( $post_id, 'rank_math_canonical_url', true ) ?: (string) get_permalink( $post_id ),
			'robots'      => is_array( $robots ) ? implode( ', ', $robots ) : 'index, follow',
		];
	}
	if ( defined( 'WPSEO_VERSION' ) ) {
		$noindex  = get_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', true );
		$nofollow = get_post_meta( $post_id, '_yoast_wpseo_meta-robots-nofollow', true );
		return [
			'title'       => get_post_meta( $post_id, '_yoast_wpseo_title', true ) ?: get_the_title( $post_id ),
			'description' => (string) get_post_meta( $post_id, '_yoast_wpseo_metadesc', true ),
			'canonical'   => (string) get_post_meta( $post_id, '_yoast_wpseo_canonical', true ),
			'robots'      => ( $noindex === '1' ? 'noindex' : 'index' ) . ', ' . ( $nofollow === '1' ? 'nofollow' : 'follow' ),
		];
	}
	if ( defined( 'AIOSEO_VERSION' ) ) {
		return [
			'title'       => get_post_meta( $post_id, '_aioseo_title', true ) ?: get_the_title( $post_id ),
			'description' => (string) get_post_meta( $post_id, '_aioseo_description', true ),
			'canonical'   => (string) get_post_meta( $post_id, '_aioseo_canonical_url', true ) ?: (string) get_permalink( $post_id ),
			'robots'      => 'index, follow',
		];
	}
	if ( defined( 'SEOPRESS_VERSION' ) ) {
		return [
			'title'       => get_post_meta( $post_id, '_seopress_titles_title', true ) ?: get_the_title( $post_id ),
			'description' => (string) get_post_meta( $post_id, '_seopress_titles_desc', true ),
			'canonical'   => (string) get_post_meta( $post_id, '_seopress_titles_canonical', true ) ?: (string) get_permalink( $post_id ),
			'robots'      => 'index, follow',
		];
	}
	if ( defined( 'THE_SEO_FRAMEWORK_VERSION' ) ) {
		return [
			'title'       => get_post_meta( $post_id, '_genesis_title', true ) ?: get_the_title( $post_id ),
			'description' => (string) get_post_meta( $post_id, '_genesis_description', true ),
			'canonical'   => (string) get_post_meta( $post_id, '_genesis_canonical_uri', true ) ?: (string) get_permalink( $post_id ),
			'robots'      => 'index, follow',
		];
	}
	return [
		'title'       => get_the_title( $post_id ),
		'description' => '',
		'canonical'   => (string) get_permalink( $post_id ),
		'robots'      => 'index, follow',
	];
}

function builder_api_field_groups( WP_REST_Request $request ): WP_REST_Response {
	nocache_headers();

	if ( ! function_exists( 'acf_get_field_groups' ) ) {
		return new WP_REST_Response( [ 'groups' => [], 'message' => 'ACF not active' ], 200 );
	}

	$groups = acf_get_field_groups();
	$result = [];

	foreach ( $groups as $group ) {
		$fields   = acf_get_fields( $group['key'] ) ?: [];
		$result[] = [
			'key'    => $group['key'],
			'title'  => $group['title'],
			'fields' => array_map( fn( $f ) => [
				'key'   => $f['key'],
				'name'  => $f['name'],
				'type'  => $f['type'],
				'label' => $f['label'],
			], $fields ),
		];
	}

	return new WP_REST_Response( [ 'groups' => $result ], 200 );
}

